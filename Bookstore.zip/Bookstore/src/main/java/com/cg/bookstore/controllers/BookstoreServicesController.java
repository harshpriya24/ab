package com.cg.bookstore.controllers;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.cg.bookstore.beans.Admin;
import com.cg.bookstore.beans.Book;
import com.cg.bookstore.beans.Customer;
import com.cg.bookstore.beans.OrderItem;
import com.cg.bookstore.exceptions.AdminDetailsNotFoundException;
import com.cg.bookstore.exceptions.BookDetailsNotFoundException;
import com.cg.bookstore.exceptions.CustomerDetailsNotFoundException;
import com.cg.bookstore.exceptions.InvalidUserDetailsException;
import com.cg.bookstore.exceptions.OrderDetailsNotFoundException;
import com.cg.bookstore.services.BookstoreServices;


@RestController
@CrossOrigin(origins= "http://localhost:4200")
public class BookstoreServicesController {
	@Autowired
	BookstoreServices bookStoreServices;
	
	@RequestMapping(value= {"/getBookDetails"}, method=RequestMethod.GET)
	public Book getBookDetails (@RequestParam long bookIsbn) throws BookDetailsNotFoundException{
		Book book = bookStoreServices.getBookDetails(bookIsbn);
		return book;
	}
	
	@RequestMapping(value= {"/addBookDetails"}, method=RequestMethod.POST)
	public Book addBookDetails(@ModelAttribute Book book) throws BookDetailsNotFoundException{
		Book book2 = bookStoreServices.acceptBookDetails(book);
		return book2;
	}
	
	@RequestMapping(value="/addCustomer",method=RequestMethod.POST)
	public Customer addCustomer(@ModelAttribute Customer customer){
		Customer customer1 = bookStoreServices.acceptCustomerDetails(customer);
		return customer1;
	}
	

	@RequestMapping(value="/getCustomer",method=RequestMethod.GET)
	public Customer getCustomer(@RequestParam String email){
		Customer customer = bookStoreServices.getCustomerDetails(email);
		return customer;
	}
	
	@RequestMapping(value="/editCustomer",method=RequestMethod.POST)
	public Customer editCustomer(@ModelAttribute Customer customer){
		Customer customer1 = bookStoreServices.editCustomer(customer);
		return customer1;
	}
	

	@RequestMapping("/removeBook")
	public String removeBookDetails(@RequestParam long bookIsbn, HttpSession session) throws BookDetailsNotFoundException {
		bookStoreServices.removeBookDetails(bookIsbn);
		return "Book Removed Successfully";
	}
	
	
	@RequestMapping("/removeCustomer")
	public String removeCustomerDetails(@RequestParam String custEmail, HttpSession session) throws CustomerDetailsNotFoundException {
		bookStoreServices.removeCustomerDetails(custEmail);
		return "Customer Details Removed Successfully";
	}
	
	
	@RequestMapping(value="/addAdmin",method=RequestMethod.POST)
	public Admin addAdmin(@ModelAttribute Admin admin){
		System.out.println(admin);
		Admin admin1 = bookStoreServices.acceptAdminDetails(admin);
		return admin1;
	}
	
	@RequestMapping("/adminLogin")
	public String adminLogin(@RequestParam String adminEmailId, @RequestParam String password, HttpSession session) throws AdminDetailsNotFoundException, InvalidUserDetailsException {
		if(bookStoreServices.adminLogin(adminEmailId, password)!=null) {
			session.setAttribute("emailId", adminEmailId);
		}
		else throw new AdminDetailsNotFoundException();
		
		Admin admin = bookStoreServices.adminLogin(adminEmailId, password);
		return admin.getAdminEmailId() + " Logged In Successfully !";
	}
	
	
	@RequestMapping("/customerLogin")
	public String customerLogin(@RequestParam String customerEmailId, @RequestParam String password, HttpSession session) throws CustomerDetailsNotFoundException, InvalidUserDetailsException {
		if(bookStoreServices.customerLogin(customerEmailId, password)!=null) {
			session.setAttribute("emailId", customerEmailId);
		}
		else throw new CustomerDetailsNotFoundException();
	
		Customer customer1= bookStoreServices.customerLogin(customerEmailId, password);
		return customer1.getCustomerFullName() + " Logged In Successfully !";
	}
	
	@RequestMapping(value="/getAllBookDetails",method=RequestMethod.GET)
	public List<Book> getAllBookDetails(){
		return bookStoreServices.getAllBookDetails();

	}

	@RequestMapping(value="/getAllCustomerDetails",method=RequestMethod.GET)
	public List<Customer> getAllCustomerDetails(){
		return bookStoreServices.getAllCustomerDetails();

	}
	
	@RequestMapping(value="/placeOrder",method=RequestMethod.POST)
	public OrderItem placeOrder(@RequestParam String customerId, @RequestParam String recepientName, @RequestParam String orderType,
			@RequestParam	int orderQuantity,@RequestParam String orderPaymentMethod, @RequestParam long bookIsbn){
		
		OrderItem order = bookStoreServices.placeOrder(customerId, recepientName, orderType, orderQuantity, orderPaymentMethod, bookIsbn);
		System.out.println(order);
		return order;
	}
		
	@RequestMapping(value= {"/getOrderDetails"}, method=RequestMethod.GET)
	public OrderItem getOrderDetails(@RequestParam long orderId) throws CustomerDetailsNotFoundException{
		OrderItem order = bookStoreServices.getOrderDetails(orderId);
		return order;
	}
	
	@RequestMapping(value= {"/getAllCustomerOrders"}, method=RequestMethod.GET)
	public List<OrderItem> getAllCustomerOrders(@RequestParam String customerId) throws CustomerDetailsNotFoundException{
	List<OrderItem> orders= bookStoreServices.getAllCustomerOrders(customerId);
		return orders;
	}
	
	/*@RequestMapping("/editProfile")
	public ModelAndView resetPasswordAction(@RequestParam String customerEmailId, String password) throws CustomerDetailsNotFoundException{
		return new ModelAndView("EditProfile", "customer", bookStoreServices.editProfile(customerEmailId, password));
	}*/
	
	@RequestMapping(value="/updateBook",method=RequestMethod.POST)
	public  Book updateBookDetails(@ModelAttribute Book book) throws  BookDetailsNotFoundException{
	    Book uBook=bookStoreServices.updateBookDetails(book);
		return uBook;
	}
	
	@RequestMapping(value="/updateOrder",method=RequestMethod.POST)
	public OrderItem updateOrder(@ModelAttribute OrderItem order) throws OrderDetailsNotFoundException{
		OrderItem uOrder=bookStoreServices.updateOrder(order);
		return uOrder;
	}
	
}
