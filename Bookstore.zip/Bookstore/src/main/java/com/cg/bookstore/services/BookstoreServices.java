package com.cg.bookstore.services;

import java.util.List;

import com.cg.bookstore.beans.Admin;
import com.cg.bookstore.beans.Book;
import com.cg.bookstore.beans.Category;
import com.cg.bookstore.beans.Customer;
import com.cg.bookstore.beans.OrderItem;
import com.cg.bookstore.exceptions.AdminDetailsNotFoundException;
import com.cg.bookstore.exceptions.BookDetailsNotFoundException;
import com.cg.bookstore.exceptions.CustomerDetailsNotFoundException;
import com.cg.bookstore.exceptions.InvalidUserDetailsException;
import com.cg.bookstore.exceptions.OrderDetailsNotFoundException;

public interface BookstoreServices {
	Book acceptBookDetails(Book book);
	Book updateBookDetails(Book book) throws  BookDetailsNotFoundException;
	Customer acceptCustomerDetails(Customer customer);
	Admin acceptAdminDetails(Admin admin);
	Customer customerLogin(String customerEmailId, String password) throws InvalidUserDetailsException, CustomerDetailsNotFoundException;
	Admin adminLogin(String adminEmailId, String password) throws InvalidUserDetailsException, AdminDetailsNotFoundException;
	List<Book> getAllBookDetails();
	List<Customer> getAllCustomerDetails();
	Book getBookDetails(long bookIsbn) throws BookDetailsNotFoundException;
	Admin getAdminDetails(String adminEmailId) throws AdminDetailsNotFoundException;
	Customer getCustomerDetails(String customerEmailId) throws CustomerDetailsNotFoundException;
	boolean removeCustomerDetails(String customerEmailId) throws CustomerDetailsNotFoundException;
	boolean removeBookDetails(long bookIsbn) throws BookDetailsNotFoundException;
	OrderItem getOrderDetails(long orderId) throws OrderDetailsNotFoundException;
	List<OrderItem> getAllOrderDetails();
	OrderItem placeOrder(String customerId,String recepientName, String orderType,
			int orderQuantity, String orderPaymentMethod, long bookIsbn);
	List<OrderItem> getAllCustomerOrders(String customerId);
	Customer editProfile(String customerEmailId, String Password) throws CustomerDetailsNotFoundException, InvalidUserDetailsException;
	Category addCategory(Category category);
	Customer editCustomer(Customer customer)throws CustomerDetailsNotFoundException;
     OrderItem updateOrder(OrderItem order) throws OrderDetailsNotFoundException;
     Admin updateAdmin(Admin admin) throws AdminDetailsNotFoundException;
}
